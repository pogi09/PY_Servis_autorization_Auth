from flask import Flask, request
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.instrumentation.flask import FlaskInstrumentor
from opentelemetry.instrumentation.requests import RequestsInstrumentor
import requests
import logging

logging.basicConfig(filename='app.log', level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Настройка OpenTelemetry
resource = Resource(attributes={"service.name": "gateway"})
trace.set_tracer_provider(TracerProvider(resource=resource))
otlp_exporter = OTLPSpanExporter(endpoint="http://jaeger:4318/v1/traces")
trace.get_tracer_provider().add_span_processor(BatchSpanProcessor(otlp_exporter))
tracer = trace.get_tracer(__name__)
FlaskInstrumentor().instrument_app(app)
RequestsInstrumentor().instrument()  # Instrument requests for trace propagation
logger.info("Gateway: Sending traces to Jaeger at http://jaeger:4318/v1/traces")

@app.route('/api/login', methods=['POST'])
def login():
    with tracer.start_as_current_span("gateway-login") as span:
        try:
            data = request.json
            username = data.get('username')
            password = data.get('password')
            span.set_attribute("user.username", username)
            
            # Вызов Auth сервиса
            auth_response = requests.post('http://auth-service:5001/auth', json={'username': username, 'password': password})
            span.set_attribute("http.status_code.auth", auth_response.status_code)
            if auth_response.status_code != 200:
                raise Exception("Authentication failed")
            
            # Вызов Storage сервиса
            storage_response = requests.get('http://storage-service:5002/storage', params={'username': username})
            span.set_attribute("http.status_code.storage", storage_response.status_code)
            storage_response.raise_for_status()
            
            logger.info(f"Gateway: Successful login for {username}")
            return storage_response.json(), storage_response.status_code
        except Exception as e:
            span.record_exception(e)
            span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
            logger.error(f"Gateway: Error during login for {username}: {str(e)}")
            return {"error": str(e)}, 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)