from flask import Flask, request
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.instrumentation.flask import FlaskInstrumentor
import redis
import logging

logging.basicConfig(filename='app.log', level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
redis_client = redis.Redis(host='redis', port=6379, decode_responses=True)

# Настройка OpenTelemetry
resource = Resource(attributes={"service.name": "storage-service"})
trace.set_tracer_provider(TracerProvider(resource=resource))
otlp_exporter = OTLPSpanExporter(endpoint="http://jaeger:4318/v1/traces")
trace.get_tracer_provider().add_span_processor(BatchSpanProcessor(otlp_exporter))
tracer = trace.get_tracer(__name__)
FlaskInstrumentor().instrument_app(app)
logger.info("Storage Service: Sending traces to Jaeger at http://jaeger:4318/v1/traces")

@app.route('/storage', methods=['GET'])
def storage():
    with tracer.start_as_current_span("storage-get") as span:
        try:
            username = request.args.get('username')
            if not username:
                raise Exception("Missing username parameter")
            redis_key = f"storage:{username}"
            redis_client.set(redis_key, f"Data for {username}")
            span.set_attribute("user.username", username)
            span.set_attribute("redis.key", redis_key)
            logger.info(f"Storage Service: Stored data for {username}")
            return {"data": f"Storage for {username}"}, 200
        except Exception as e:
            span.record_exception(e)
            span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
            logger.error(f"Storage Service: Error for {username}: {str(e)}")
            return {"error": str(e)}, 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002)